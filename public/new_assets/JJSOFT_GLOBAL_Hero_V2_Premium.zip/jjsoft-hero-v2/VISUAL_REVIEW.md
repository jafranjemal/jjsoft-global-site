# Visual review — why the old hero failed

The old device group was not failing because of color. It was failing because of silhouette, depth and camera language.

## Old problems

1. **Laptop read as two boxes**, not a laptop. The base was too flat, screen/body connection was weak, and there was no visible hinge, trackpad or convincing keyboard deck.
2. **Phone had almost no product silhouette**. A thin rectangle with a texture does not visually read as premium hardware.
3. **Tablet was a dark slab**. It was oversized and too front-on, so it looked like a black poster rather than a device.
4. **All three products were too close to one Z-depth**. That flattened the showcase and made it look assembled rather than photographed.
5. **Wide camera language weakened the hero**. Premium product renders generally benefit from a narrower FOV and deliberate 3/4 angles.
6. **The globe competed with the devices** instead of acting as a backdrop.
7. **The platform was visually heavier than the products**, which stole attention.

## V2 corrections

- Laptop: recognisable base, metal shell, raised keyboard, trackpad, hinge, screen bezel, 3/4 inward angle.
- Phone: rounded metal/glass body, front detail, moved closest to the camera as the center focal device.
- Tablet: thinner body, visible bezel/camera, inward right-side angle.
- Depth triangle: laptop left/back, phone center/front, tablet right/back.
- Camera: 36° FOV for stronger product compression and less primitive-looking perspective.
- Globe: moved behind and slightly higher.
- Stage: lower and slimmer with a controlled red front light arc.
