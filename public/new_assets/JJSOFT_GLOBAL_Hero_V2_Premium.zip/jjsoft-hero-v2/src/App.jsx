import GlobalHero from './components/GlobalHero'
export default function App(){ return <GlobalHero/> }
