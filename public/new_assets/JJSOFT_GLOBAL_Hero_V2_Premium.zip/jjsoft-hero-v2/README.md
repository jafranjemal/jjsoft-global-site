# JJSOFT GLOBAL Hero V2 — premium device showcase

This rebuild addresses the specific visual failures in the earlier hero:

- Laptop now has a recognizable base, raised keyboard, trackpad, hinge, metal lid, bezel and real 3/4 presentation angle.
- Phone now has a rounded metal frame, glass face, dynamic-island detail and sits forward of the other devices.
- Tablet now has a thin premium body, visible bezel/camera detail and turns inward from the right.
- Device spacing uses a deliberate showcase triangle: laptop left/back, phone center/front, tablet right/back.
- Camera uses a narrower 36° FOV for a premium product-render look instead of a flat/wide primitive look.
- Globe remains behind the products rather than swallowing their silhouettes.
- The stage is slimmer and the red front accent is separated from the devices.
- Screen assets are higher-detail local PNGs; no network dependency.
- The three new GLB models are local and independently reusable.

## Run

```bash
npm install
npm run dev
```

## Key files

- `src/components/PremiumDevices.jsx` — device placement and showcase angles
- `src/components/GlobalHero.jsx` — camera, scene shift, lighting and composition
- `public/assets/models/*-premium.glb` — improved device models
- `public/assets/screens/*` — screen textures

## Device placement (desktop)

- Laptop: `position [-1.25,-0.48,0.95]`, `rotationY +0.27`
- Phone: `position [0.40,-0.34,1.72]`, almost front-facing
- Tablet: `position [1.56,-0.18,1.02]`, `rotationY -0.29`

This is intentional. Do not line the devices up on a single flat Z plane; doing that destroys the showcase depth.
